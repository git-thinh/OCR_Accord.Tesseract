﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Mouse gesture recognition with Dynamic Time Warping SVMs")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Accord.NET")]
[assembly: AssemblyProduct("Accord.NET Framework")]
[assembly: AssemblyCopyright("Copyright © César Souza, 2009-2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyDescription(
@"This sample application shows how to use variable-length Support Vector Machines for sequence classification using the Dynamic Time Warping kernel function. Using this function, SVMs can accept variable-length input vectors and handle them as sequence of observations, just like Hidden Markov Models (HMMs) can do.

You can also find the HMM version of this application in the Statistics sample application folder.")]



// This sets the default COM visibility of types in the assembly to invisible.
// If you need to expose a type to COM, use [ComVisible(true)] on that type.
[assembly: ComVisible(false)]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]
